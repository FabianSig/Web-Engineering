let board = ['', '', '', '', '', '', '', '', ''];
let currentPlayer = 'X';
let gameOver = false;

function makeMove(index) {
    // to be implemented
}

function resetGame() {
    // to be implemented
}
